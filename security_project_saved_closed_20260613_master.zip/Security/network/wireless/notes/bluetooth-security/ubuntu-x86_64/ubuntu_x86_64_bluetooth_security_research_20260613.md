# Security / notes / bluetooth-security / ubuntu-x86_64
## Ubuntu x86-64 Bluetooth security research note

Date: 2026-06-13
Status: research snapshot / defensive use only

## Scope
Ubuntu x86-64 laptop Bluetooth controls relevant to:
- receiving internet from Motorola 2025
- avoiding Bluetooth tethering
- reducing local Bluetooth attack surface
- preserving the ability to use Wi-Fi hotspot or USB tethering

## Linux/Ubuntu Bluetooth stack basics
On Ubuntu, Bluetooth is typically handled by:
- kernel Bluetooth drivers
- rfkill wireless kill-switch interface
- BlueZ user-space Bluetooth stack
- bluetooth.service / bluetoothd
- desktop/network-manager Bluetooth UI integrations

## Security control layers

### 1. Ordinary UI disablement
Turn Bluetooth off in Ubuntu Settings. This is easy and reversible, but may not be sufficient if a service or user action turns it back on.

### 2. rfkill soft-block
Use rfkill to block Bluetooth radios at the kernel rfkill interface.

Commands:
```bash
rfkill
sudo rfkill block bluetooth
rfkill
```

This should show Bluetooth as soft-blocked if the adapter supports rfkill.

To undo:
```bash
sudo rfkill unblock bluetooth
```

### 3. Stop/disable BlueZ service
If Bluetooth is not needed on the Ubuntu laptop, stop and disable the service:

```bash
sudo systemctl stop bluetooth.service
sudo systemctl disable bluetooth.service
systemctl status bluetooth.service
```

Stronger local lockout:
```bash
sudo systemctl mask bluetooth.service
```

To undo:
```bash
sudo systemctl unmask bluetooth.service
sudo systemctl enable --now bluetooth.service
```

### 4. BlueZ AutoEnable
BlueZ has an AutoEnable setting in main.conf that controls whether controllers are enabled when found/plugged in. Set AutoEnable=false where applicable:

```bash
sudo cp /etc/bluetooth/main.conf /etc/bluetooth/main.conf.bak.$(date +%Y%m%d%H%M%S)
sudo nano /etc/bluetooth/main.conf
```

Add or edit:
```ini
[Policy]
AutoEnable=false
```

Then:
```bash
sudo systemctl restart bluetooth.service
```

Note: On some distributions/builds, service state, desktop settings, rfkill state, and main.conf can interact. Verify after reboot.

### 5. Remove unneeded pairing trust
If Bluetooth remains installed but off, also remove old paired/trusted devices:

```bash
bluetoothctl
paired-devices
remove XX:XX:XX:XX:XX:XX
quit
```

## Ubuntu checklist for Motorola-to-laptop internet

Preferred wireless:
- Ubuntu connects to Motorola Wi-Fi hotspot.
- Ubuntu Bluetooth remains off or rfkill-blocked.

Preferred wired:
- Ubuntu receives USB tethering as a wired/USB network interface.
- Bluetooth remains off or rfkill-blocked.

Avoid:
- Bluetooth tethering
- pairing phone with Ubuntu for internet access
- enabling Bluetooth on Ubuntu when starting the hotspot

## Verification commands

Before connecting:
```bash
rfkill
systemctl status bluetooth.service --no-pager
bluetoothctl show
nmcli device status
```

After enabling Motorola Wi-Fi hotspot:
```bash
rfkill
nmcli device status
ip route
```

After enabling Motorola USB tethering:
```bash
nmcli device status
ip addr
ip route
```

If Bluetooth turns on unexpectedly:
```bash
journalctl -u bluetooth.service --since "10 minutes ago" --no-pager
journalctl --since "10 minutes ago" | grep -i bluetooth
```

## Open Ubuntu questions
- Is the laptop using Wi-Fi hotspot or Bluetooth PAN/tethering?
- Does NetworkManager expose a Bluetooth network device after the phone prompt?
- Does the Ubuntu desktop environment auto-enable Bluetooth when phone sharing is selected?
- Is Bluetooth built into the Wi-Fi card, and can it be disabled independently in BIOS/UEFI?
