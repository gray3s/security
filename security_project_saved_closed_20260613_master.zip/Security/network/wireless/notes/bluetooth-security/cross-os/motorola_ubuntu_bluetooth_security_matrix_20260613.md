# Security / notes / bluetooth-security / cross-os
## Cross-OS Bluetooth security notes: Android Motorola 2025 + Ubuntu x86-64

Date: 2026-06-13
Status: research snapshot / defensive use only

## Current scenario
- Android phone: Motorola 2025.
- Laptop: Ubuntu x86-64.
- Goal: use Motorola cellular data to put Ubuntu on the internet.
- Security concern: Bluetooth is being requested/enabled when using a tethered/hotspot path.
- Current diagnosis: the workflow is likely selecting Bluetooth tethering or a nearby-device pairing path.

## Correct target architecture

### Preferred option 1: Wi-Fi hotspot
Motorola:
- cellular data on
- Wi-Fi hotspot on
- Bluetooth tethering off
- Bluetooth off

Ubuntu:
- Wi-Fi on
- Bluetooth off or rfkill-blocked
- connect to Motorola hotspot by SSID/password

### Preferred option 2: USB tethering
Motorola:
- cellular data on
- USB tethering on after cable connection
- Bluetooth tethering off
- Bluetooth off

Ubuntu:
- sees phone as USB/wired network interface
- Bluetooth off or rfkill-blocked

## Avoided architecture
Bluetooth tethering / Bluetooth PAN:
- Requires Bluetooth on both devices.
- Requires pairing/trust relationship.
- Expands wireless attack surface.
- Unnecessary for the stated Motorola-to-Ubuntu internet goal.

## Test matrix

| Test | Motorola setting | Ubuntu setting | Expected result |
|---|---|---|---|
| A | Wi-Fi hotspot only | Wi-Fi connect, Bluetooth off | Internet works; Bluetooth remains off |
| B | USB tethering only | USB network, Bluetooth off | Internet works; Bluetooth remains off |
| C | Bluetooth tethering | Bluetooth on both devices | Internet may work; reject for this project |
| D | Wi-Fi hotspot with Ubuntu rfkill block bluetooth | Bluetooth blocked | Internet should still work |
| E | USB tethering with Ubuntu rfkill block bluetooth | Bluetooth blocked | Internet should still work |

## Minimal command set for Ubuntu

Block Bluetooth:
```bash
sudo rfkill block bluetooth
```

Confirm Wi-Fi/hotspot connection:
```bash
nmcli device status
ip route
```

Confirm Bluetooth remains blocked:
```bash
rfkill
```

Check service:
```bash
systemctl status bluetooth.service --no-pager
```

## Minimal Android user-level checks

Before enabling internet sharing:
- Bluetooth off.
- Bluetooth tethering off.
- Wi-Fi hotspot configured with password.
- Nearby devices permission denied for nonessential apps.

After enabling sharing:
- Verify no Bluetooth prompt.
- Verify Ubuntu connects by Wi-Fi or USB, not Bluetooth.

## Project decision
Bluetooth is classified under:
Security/network/wireless/

Research notes are stored under:
Security/notes/bluetooth-security/

The Security project is saved and closed after packaging this snapshot.
