# Security / notes / bluetooth-security
## Source references snapshot

Date: 2026-06-13

## Sources consulted

- Android Bluetooth permissions: Android Developers documentation.
- Android UserManager restrictions: Android Developers / AOSP / Microsoft API mirror for specific restriction descriptions.
- Android Management API policies: Google Android Management API documentation.
- Linux rfkill: man7 Linux manual page and NetworkManager RFKill documentation.
- BlueZ main.conf AutoEnable: BlueZ main.conf source/reference.
- bluetoothctl behavior: Debian/BlueZ manual page.
- Ubuntu/systemd disablement: Ubuntu community guidance; use with local verification.

## Citation mapping for final answer
Use web citations in the final answer for:
- Android 12+ Bluetooth permissions.
- DISALLOW_BLUETOOTH vs DISALLOW_CONFIG_BLUETOOTH.
- Android Management API bluetoothDisabled.
- rfkill.
- NetworkManager rfkill model.
- BlueZ AutoEnable.
