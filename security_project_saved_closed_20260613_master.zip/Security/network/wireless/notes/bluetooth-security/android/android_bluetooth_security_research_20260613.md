# Security / notes / bluetooth-security / android
## Android Bluetooth security research note

Date: 2026-06-13
Status: research snapshot / defensive use only

## Scope
Android Bluetooth security controls relevant to:
- Motorola 2025 active phone
- phone-to-Ubuntu internet sharing
- avoiding Bluetooth tethering
- preventing unwanted Bluetooth enablement where practical

## Key Android security distinctions

### 1. User toggle vs durable lockout
The ordinary Bluetooth toggle is reversible and is not a policy-grade lockout. It is suitable for routine use, but not enough when the goal is to prevent accidental or app/system-driven Bluetooth activity.

### 2. App-level Bluetooth permissions
On Android 12 / API 31 and later, Bluetooth access is separated into runtime permissions:
- BLUETOOTH_SCAN
- BLUETOOTH_ADVERTISE
- BLUETOOTH_CONNECT

These map in the Android user interface to Nearby devices permission prompts/settings. Denying Nearby devices permissions can reduce app-level Bluetooth exposure, but it does not disable the Bluetooth radio globally.

### 3. Device-owner / enterprise policy
The strongest official non-root option is device-owner / Android Enterprise policy. The relevant policy distinction:
- DISALLOW_CONFIG_BLUETOOTH: blocks Bluetooth configuration but does not fully prevent Bluetooth use.
- DISALLOW_BLUETOOTH: disallows Bluetooth on the device more completely.
- Android Management API bluetoothDisabled: current policy field for disabling Bluetooth; preferred over bluetoothConfigDisabled.

This usually requires fully managed / device-owner enrollment and may require factory reset.

## Current Motorola 2025 interpretation
The user reports that a "tethered hotspot" prompts Bluetooth on both ends. This strongly suggests Bluetooth tethering or a nearby-device pairing/sharing workflow rather than ordinary Wi-Fi hotspot.

For phone-to-Ubuntu internet sharing, Bluetooth is unnecessary. Use:
- Wi-Fi hotspot, or
- USB tethering

Avoid:
- Bluetooth tethering
- pairing prompts
- nearby-device sharing flows
- any flow requiring Bluetooth on both devices

## Android checklist for Motorola 2025

1. Settings > Network & internet > Hotspot & tethering
   - Use Wi-Fi hotspot only, or USB tethering only.
   - Keep Bluetooth tethering off.

2. Settings > Connected devices > Connection preferences > Bluetooth
   - Bluetooth off.
   - Remove unused paired devices.

3. Settings > Privacy > Permission manager > Nearby devices
   - Deny nonessential apps.

4. Disable optional reenable/discovery paths where present:
   - Quick Share / Nearby Share
   - Fast Pair
   - Android Auto wireless
   - Motorola Smart Connect / Ready For
   - wearable/headphone companion apps
   - carrier/OEM connection-sharing wizard

5. Verification:
   - Start Wi-Fi hotspot only.
   - Confirm Bluetooth remains off.
   - Connect Ubuntu over Wi-Fi.
   - Repeat using USB tethering.
   - If either path requests Bluetooth, document the exact UI text and path.

## Open Android questions
- Does Motorola's Android 2025 build expose a separate Bluetooth tethering toggle?
- Is the prompt coming from Android settings, Motorola software, carrier software, or Ubuntu pairing?
- Does "tethered hotspot" mean USB tethering, Bluetooth tethering, or a carrier/Motorola sharing wizard?
- Does wireless Android Auto or Motorola Smart Connect reenable Bluetooth?
