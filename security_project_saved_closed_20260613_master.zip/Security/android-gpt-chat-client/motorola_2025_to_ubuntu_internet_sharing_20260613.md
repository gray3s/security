# Security / android-gpt-chat-client
## Use case: Motorola 2025 provides internet to Ubuntu laptop

Date: 2026-06-13
Status: clarified implementation note

## User clarified use case
The Motorola 2025 is used to put an Ubuntu laptop on the internet.

## Correct interpretation
This does not require Bluetooth.

The two appropriate methods are:
1. Wi-Fi hotspot: Motorola broadcasts a Wi-Fi network; Ubuntu connects to that Wi-Fi network.
2. USB tethering: Motorola shares internet over a USB cable; Ubuntu sees it as a wired/USB network connection.

Bluetooth tethering should not be used for this workflow.

## If Android asks to enable Bluetooth on both ends
That is likely not the normal Wi-Fi hotspot path. It likely means:
- Bluetooth tethering was selected, or
- a nearby-device pairing/connection-sharing wizard was selected, or
- an OEM/carrier feature is trying to route the connection through Bluetooth discovery or pairing.

Back out of that path and use Wi-Fi hotspot or USB tethering directly.

## Recommended method A: Wi-Fi hotspot
On Motorola:
1. Settings > Network & internet > Hotspot & tethering.
2. Choose Wi-Fi hotspot.
3. Configure:
   - network name
   - password
   - security WPA2/WPA3 if available
   - do not use open/no-password hotspot
4. Turn Wi-Fi hotspot on.
5. Confirm Bluetooth remains off.
6. On Ubuntu:
   - open Wi-Fi menu
   - choose the Motorola hotspot network
   - enter password

## Recommended method B: USB tethering
On Motorola:
1. Confirm cellular data is on.
2. Connect Motorola to Ubuntu laptop by USB cable.
3. Settings > Network & internet > Hotspot & tethering.
4. Turn on USB tethering.
5. Confirm Bluetooth remains off.
6. On Ubuntu:
   - open network settings
   - look for a new wired/USB Ethernet connection
   - confirm internet access

## Avoid
- Bluetooth tethering
- Nearby-device internet sharing prompts
- Pairing workflow that asks for Bluetooth on both ends
- Any carrier/OEM connection-sharing wizard that does not clearly say Wi-Fi hotspot or USB tethering

## Verification
Before and after starting the connection:
- Confirm Bluetooth tile remains off.
- Confirm Settings > Hotspot & tethering > Bluetooth tethering remains off.
- Confirm Ubuntu is connected via Wi-Fi or USB network, not Bluetooth.
