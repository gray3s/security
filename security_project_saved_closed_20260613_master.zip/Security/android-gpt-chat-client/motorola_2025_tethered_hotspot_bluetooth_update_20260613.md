# Security / android-gpt-chat-client
## Update: tethered hotspot prompts Bluetooth on both ends

Date: 2026-06-13
Status: narrowed diagnosis

## New user observation
When the user uses a "tethered hotspot" on the Motorola 2025, Android wants to enable Bluetooth on both ends.

## Interpretation
This strongly suggests that the selected path is Bluetooth tethering, or a tethering workflow that includes Bluetooth as the transport layer, rather than a plain Wi-Fi hotspot.

Bluetooth tethering requires Bluetooth to be enabled and paired/active on both devices. Therefore, a prompt to enable Bluetooth on both ends is expected if Bluetooth tethering is selected.

## Distinction to preserve
- Wi-Fi hotspot: phone broadcasts Wi-Fi; client connects by Wi-Fi. Bluetooth should not be required.
- USB tethering: phone shares internet over USB cable. Bluetooth should not be required.
- Bluetooth tethering: phone shares internet over Bluetooth. Bluetooth is required on both devices.
- Nearby/device-sharing flows: may use Bluetooth for discovery even if the final data path is Wi-Fi or another transport.

## Revised mitigation
1. Avoid Bluetooth tethering entirely.
2. Use Wi-Fi hotspot only if wireless sharing is needed.
3. Use USB tethering only if a cable connection is intended.
4. Before starting hotspot/tethering, inspect:
   - Settings > Network & internet > Hotspot & tethering
   - Ensure "Bluetooth tethering" is off.
   - Enable only "Wi-Fi hotspot" or only "USB tethering."
5. If a setup path asks to enable Bluetooth on both devices, back out and choose Wi-Fi hotspot or USB tethering instead.
6. If Wi-Fi hotspot still triggers Bluetooth, test whether Quick Share/Nearby Share, Android Auto, Motorola Smart Connect/Ready For, or a carrier connection-sharing wizard is being invoked.

## Current likely diagnosis
The issue is probably not "hotspot enables Bluetooth" in the generic sense. It is more likely:
- the user is selecting Bluetooth tethering, or
- Android/Motorola is routing a "tethered hotspot" workflow through Bluetooth tethering or nearby-device pairing.

## Next test
Run this manual comparison:
1. Start only Wi-Fi hotspot.
   - Does Bluetooth turn on?
2. Start only USB tethering with a cable.
   - Does Bluetooth turn on?
3. Start Bluetooth tethering.
   - Confirm it asks for Bluetooth on both devices.

If only case 3 asks for Bluetooth, the fix is simply to avoid Bluetooth tethering.
If case 1 or 2 asks for Bluetooth, then investigate Motorola/OEM connection-sharing features.
