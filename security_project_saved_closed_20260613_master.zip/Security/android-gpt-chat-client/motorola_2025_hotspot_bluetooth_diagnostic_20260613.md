# Security / android-gpt-chat-client
## Diagnostic note: Motorola 2025 hotspot triggers Bluetooth issue

Date: 2026-06-13
Status: active diagnostic note

## Clarified device status
- Google Pixel 6a: currently unusable by user. Exclude from Bluetooth/hotspot testing unless lawful account/PIN recovery succeeds later.
- Motorola 2025: active test phone and the relevant affected device.
- Observed issue: when hotspot is started on the Motorola 2025, Bluetooth is inadvertently enabled or otherwise affected.

## Revised problem statement
The immediate problem is not generic Bluetooth lockout across Android devices. The immediate problem is diagnosing and mitigating a Motorola 2025 behavior where starting mobile hotspot appears to trigger Bluetooth-related activity.

## Working hypotheses to test
1. Hotspot startup is enabling Bluetooth tethering.
2. Hotspot startup is triggering a network-sharing bundle that includes Bluetooth.
3. Motorola/OEM connectivity feature is enabling Bluetooth for device discovery or accessory handoff.
4. Android Auto, Quick Share/Nearby Share, Fast Pair, or a companion app is reacting to hotspot startup.
5. Carrier hotspot provisioning or tethering UI is touching multiple tethering modes.
6. The Bluetooth toggle appears enabled, but only scanning/discovery or a system Bluetooth service is being activated.
7. A third-party app is monitoring hotspot state and enabling Bluetooth.

## Immediate non-root test plan
1. Before enabling hotspot:
   - Confirm Bluetooth toggle state.
   - Note currently running apps.
   - Note whether Android Auto, Quick Share, Motorola Smart Connect/Ready For, wearable apps, headphone apps, or carrier apps are installed/enabled.

2. Start hotspot:
   - Observe whether the Bluetooth tile turns on.
   - Observe whether Bluetooth tethering turns on specifically.
   - Observe whether any pairing/discovery notification appears.
   - Record exact time of event.

3. After hotspot starts:
   - Go to Settings > Connected devices > Connection preferences > Bluetooth.
   - Go to Settings > Network & internet > Hotspot & tethering.
   - Check whether Bluetooth tethering is enabled.
   - Check Quick Share/Nearby Share state.
   - Check Android Auto/wireless Android Auto state.

4. Mitigation attempts:
   - Disable Bluetooth tethering if present.
   - Disable Quick Share/Nearby Share.
   - Disable Android Auto wireless/auto-launch features.
   - Disable Motorola Smart Connect / Ready For if present.
   - Deny Nearby devices permission to nonessential apps.
   - Remove paired Bluetooth devices.
   - Reboot and retest hotspot startup.

## ADB diagnostic commands, if using a trusted computer
```bash
adb devices
adb shell settings get global bluetooth_on
adb shell dumpsys bluetooth_manager
adb shell dumpsys connectivity
adb shell dumpsys tethering
adb shell dumpsys package | grep -i "BLUETOOTH" -B 3 -A 6
adb shell cmd appops query-op BLUETOOTH_SCAN
adb shell cmd appops query-op BLUETOOTH_CONNECT
```

Suggested capture sequence:
```bash
date > moto_hotspot_bluetooth_test.log
adb shell settings get global bluetooth_on >> moto_hotspot_bluetooth_test.log
adb shell dumpsys bluetooth_manager >> moto_hotspot_bluetooth_test.log
adb shell dumpsys tethering >> moto_hotspot_bluetooth_test.log
```
Then enable hotspot, repeat the same commands, and compare before/after.

## Current recommendation
Do not factory-reset yet. First determine whether the hotspot action is enabling:
- global Bluetooth,
- Bluetooth tethering,
- Bluetooth scanning/discovery,
- a Motorola connectivity feature,
- or a companion app behavior.

The Motorola 2025 remains the correct test device because it is usable and exhibits the relevant issue.
