# Security / android-gpt-chat-client
## Implementation plan: Android Bluetooth disablement and lockout

Date: 2026-06-13
Status: implementation draft

## Goal
Disable Bluetooth on an Android phone and, where possible, prevent it from being reenabled or used by applications, system integrations, or network-adjacent services.

## Track A — Reversible mitigation without reset/root

### A1. Disable and clean Bluetooth state
1. Settings > Connected devices > Connection preferences > Bluetooth > Off.
2. Settings > Connected devices > Saved devices / Previously connected devices.
3. Forget/remove every paired Bluetooth device.
4. Reboot.
5. Confirm Bluetooth remains off after reboot.

### A2. Remove app access to Bluetooth/Nearby devices
1. Settings > Privacy > Permission manager.
2. Open Nearby devices.
3. Deny every nonessential app.
4. Also review Location permission, because Bluetooth scanning and nearby-device functions may overlap with location-adjacent behavior.
5. Remove unnecessary apps that request Bluetooth/Nearby devices.

### A3. Disable Bluetooth reenable paths
Check and disable where present:
- Android Auto automatic launch / wireless Android Auto.
- Quick Share / Nearby Share.
- Fast Pair / saved accessories.
- Wearable/watch/headphone companion apps.
- Find My Device / device-finding network settings if they rely on Bluetooth.
- OEM assistant/device-connectivity features.

### A4. Add operational discipline
- Keep Bluetooth Quick Settings tile visible so state can be checked quickly.
- Check Bluetooth after reboot, charging in a car, launching Android Auto, opening maps/media apps, and connecting USB accessories.
- Log any automatic reenable event with timestamp, app/activity, and whether a car/accessory was involved.

## Track B — ADB-assisted audit

Prerequisites:
- Trusted computer.
- Android Platform Tools installed.
- Developer Options and USB debugging enabled on the phone.
- USB cable connection accepted by the phone.

Commands:
```bash
adb devices
adb shell settings get global bluetooth_on
adb shell dumpsys bluetooth_manager
adb shell pm list permissions -g | grep -i bluetooth
adb shell dumpsys package | grep -i "android.permission.BLUETOOTH" -B 3 -A 6
adb shell dumpsys package | grep -i "android.permission.BLUETOOTH_SCAN" -B 3 -A 6
adb shell dumpsys package | grep -i "android.permission.BLUETOOTH_CONNECT" -B 3 -A 6
```

Use ADB for audit and logging, not as the primary durable lockout. Hidden settings commands vary by Android version and OEM build.

## Track C — Strong official route: device owner / Android Enterprise

This is the best official non-root method.

High-level steps:
1. Back up the phone.
2. Decide whether the phone can be treated as a fully managed test device.
3. Factory reset may be required.
4. Enroll the phone as a fully managed / device-owner device.
5. Use a DPC/MDM/Android Management API policy that sets Bluetooth disabled.
6. Verify Bluetooth cannot be turned on in Settings.
7. Reboot and retest.
8. Test Android Auto, Quick Share, accessory-pairing prompts, and app Bluetooth permissions.

Policy target:
- Prefer full Bluetooth disablement, not merely Bluetooth configuration disablement.
- In Android Management API terms, prefer bluetoothDisabled=true over bluetoothConfigDisabled=true.

Possible testing approach:
- Use Test DPC only as a development/test tool, not as a production security tool.
- If using Test DPC, set it as device owner after factory reset, then test whether the Bluetooth restriction is available and enforced.

Official AOSP testing command for Test DPC device-owner setup:
```bash
adb shell dpm set-device-owner "com.afwsamples.testdpc/.DeviceAdminReceiver"
```

Important:
- Device-owner setup generally requires no existing user accounts and often a factory-reset state.
- Removing a device owner may require wiping the device.
- Work-profile mode is weaker for this goal because it mostly manages the work profile, not the whole personal side of the device.

## Track D — Root/custom-ROM route

Only consider this on a spare device:
1. Full backup and rollback plan.
2. Unlock bootloader if supported.
3. Root or install custom ROM.
4. Disable Bluetooth system packages/services/modules only after device-specific research.
5. Verify no boot loops, system crashes, Android Auto dependency failures, or OTA update failures.

This is high-risk and device-specific.

## Recommended sequence for the user's phone
1. Start with Track A now.
2. Use Track B to collect baseline evidence.
3. If the target is real lockout, move to Track C on a spare or resettable phone.
4. Avoid Track D unless this becomes a dedicated security test device.

## Verification checklist
- Bluetooth toggle is off.
- No paired devices remain.
- Nearby devices permission denied for nonessential apps.
- Bluetooth remains off after reboot.
- Bluetooth remains off after Android Auto / car connection test.
- Bluetooth remains off after opening maps/media/wearable/device-finder apps.
- If device-owner policy is applied: Settings cannot turn Bluetooth back on.
- ADB audit output saved before and after policy application.
